import { CartDTO } from './cart-dto';

describe('CartDTO', () => {
  it('should create an instance', () => {
    expect(new CartDTO()).toBeTruthy();
  });
});
