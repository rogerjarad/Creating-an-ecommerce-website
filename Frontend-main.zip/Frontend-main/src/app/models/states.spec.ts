import { States } from './states';

describe('States', () => {
  it('should create an instance', () => {
    expect(new States()).toBeTruthy();
  });
});
