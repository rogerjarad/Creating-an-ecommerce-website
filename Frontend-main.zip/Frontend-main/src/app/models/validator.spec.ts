import { Validator } from './validator';

describe('Validator', () => {
  it('should create an instance', () => {
    expect(new Validator()).toBeTruthy();
  });
});
